import pygame, sys, time
from Script.Color import *

pygame.init()

cSec = 0
cFrame = 0
FPS = 0

tile_size = 32

fps_font = pygame.font.Font("C:\\Windows\\Fonts\\Verdana.ttf", 20)

def show_fps():
	fps_overlay = fps_font.render(str(FPS), True, Color.YellowGreen)
	window.blit(fps_overlay, (0,0))
	
def create_window():
	global window, window_height, window_width, window_title
	window_width, window_height = 800, 600
	window_title = "Test"
	pygame.display.set_caption(window_title)
	window = pygame.display.set_mode((window_width, window_height), pygame.HWSURFACE|pygame.DOUBLEBUF)

def count_fps():
	global cSec, cFrame, FPS
	
	if cSec == time.strftime("%S"):
		cFrame += 1
	else:
		FPS = cFrame
		cFrame = 0
		cSec = time.strftime("%S")

create_window()

isRunning = True

while isRunning:
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			isRunning = False
	
			
	#LOGIC
	count_fps()
	
	# Render Graphics
	window.fill(Color.Black)
	
	#Render Simple Terrain Grid
	for x in range(0, 640, tile_size):
		for y in range (0, 480, tile_size):
			pygame.draw.rect(window, Color.White, (x,y, tile_size, tile_size), 1)
	
	show_fps()
	
	pygame.display.update()



pygame.quit()
sys.exit()
