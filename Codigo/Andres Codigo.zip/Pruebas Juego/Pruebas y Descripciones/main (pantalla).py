import pygame, sys

pygame.init()

def create_window():
	global window, window_height, window_width, window_title
	window_width, window_height = 800, 600
	window_title = "Test"
	pygame.display.set_caption(window_title)
	window = pygame.display.set_mode((window_width, window_height), pygame.HWSURFACE|pygame.DOUBLEBUF)

create_window()

isRunning = True

while isRunning:
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			isRunning = False
			
			
	window.fill((0, 0, 0))
	
	pygame.display.update()



pygame.quit()
sys.exit()
