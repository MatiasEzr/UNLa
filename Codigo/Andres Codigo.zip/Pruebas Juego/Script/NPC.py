import pygame

pygame.init()

def obtener_caras(sprite):
	
	faces = ()
	
	size = sprite.get_size()
	tile_size = (int(size[0] / 2), int(size[1] / 2))
	
	sur = pygame.Surface(tile_size, pygame.HWSURFACE|pygame.SRCALPHA)
	sur.blit(sprite, (0, 0), (0, 0, tile_size[0], tile_size[1]))
	faces["sur"] = sur
	
	norte = pygame.Surface(tile_size, pygame.HWSURFACE|pygame.SRCALPHA)
	norte.blit(sprite, (0, 0), (tile_size[0], tile_size[1]))
	faces["norte"] = norte
	
	este = pygame.Surface(tile_size, pygame.HWSURFACE|pygame.SRCALPHA)
	este.blit(sprite, (0, 0), (tile_size[0], 0, tile_size[0], tile_size[1])
	faces["este"] = este
	
	oeste = pygame.Surface(tile_size, pygame.HWSURFACE|pygame.SRCALPHA)
	oeste.blit(sprite, (0, 0), (0, tile_size[1], tile_size[0], tile_size[1])
	faces["oeste"] = oeste
	
	return faces
