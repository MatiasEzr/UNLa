class Globales:
	
	camera_x = 0
	camera_y = 0
	camera_mov = 0
