import pygame 
from NPC import *

pygame.init()

class Jugador()
	
	def __init__(self, name):
		self.name = name
		sprite = pygame.image.load("Graficos\\player.png")
		size = sprite.get_size()
		self.width = size[0]
		self.height = size[1]
		
		#Obtener caras jugador
		
		self.faces = get_faces(sprite)
		
