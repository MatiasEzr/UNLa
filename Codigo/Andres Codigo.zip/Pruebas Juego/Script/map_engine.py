import pygame
from Script.texturas import *

class Mapa_Config:
	
	def add_tile(tile, pos, addTo):
		addTo.blit(tile, (pos[0] * Tiles.size, pos[1] * Tiles.size))
	
	def cargar_mapa(file):
		with open(file, "r") as mapfile:
			map_data = mapfile.read()
		#Read Map Data
		map_data = map_data.split("-")	#Split dentro de la lista de titulos
		
		map_size = map_data[len(map_data)-1]	#Obtener Dimensiones de Mapa
		
		map_data.remove(map_size)
		
		map_size = map_size.split(",")
		
		map_size[0] = int(map_size[0]) * Tiles.size
		map_size[1] = int(map_size[1]) * Tiles.size
		
		tiles = []
		
		for tile in range (len(map_data)):
			map_data[tile] = map_data[tile].replace("\n", "")
			tiles.append(map_data[tile].split(":"))				#Pocision de Split de las texturas
		
		for tile in tiles:
			tile[0] = tile[0].split(",")		# Pocision Split dentro de la lista
			pos = tile[0]
			for p in pos:
				pos[pos.index(p)] = int(p)		# Convierte a Entero
			
			tiles[tiles.index(tile)] = (pos, tile[1])		# Guarda a la lista Tile
			
		# Create terrain
		terrain = pygame.Surface(map_size, pygame.HWSURFACE)
		
		for tile in tiles:
			if tile[1] in Tiles.Textura_Tags:
				Mapa_Config.add_tile(Tiles.Textura_Tags[tile[1]], tile[0], terrain)
		return terrain
