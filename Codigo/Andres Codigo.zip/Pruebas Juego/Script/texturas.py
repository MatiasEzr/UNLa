import pygame

pygame.init()

class Tiles:
	
	size = 32
	
	def Cargar_Texturas(file, size):
		bitmap = pygame.image.load(file)
		bitmap = pygame.transform.scale(bitmap, (size, size))
		surface = pygame.Surface((size, size), pygame.HWSURFACE|pygame.SRCALPHA)
		surface.blit(bitmap, (0, 0))
		return surface
		
	Pasto = Cargar_Texturas("Graficos\\grass.png", size)
	
	Piedra = Cargar_Texturas("Graficos\\stone.png", size)
	
	Agua = Cargar_Texturas("Graficos\\water.png", size)
	
	

	Textura_Tags = {"1" : Pasto, "2" : Piedra, "3" : Agua}
